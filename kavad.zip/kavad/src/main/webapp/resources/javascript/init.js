$(document).ready(function(){
	$("input.dateTimeInput").AnyTime_picker({format: "%d/%m/%Y - %H:%i"});

});